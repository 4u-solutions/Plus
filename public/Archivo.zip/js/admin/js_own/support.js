function reportissue(user) {
    window.open("http://localhost/reportissues/?f="+window.location.host+"&d="+window.location.href+"&us="+user, "_blank", "toolbar=no, scrollbars=no, resizable=no, top=100, left=180, width=960, height=530");
}